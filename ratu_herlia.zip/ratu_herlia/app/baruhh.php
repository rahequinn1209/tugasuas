<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class baruhh extends Model
{
    //
}
